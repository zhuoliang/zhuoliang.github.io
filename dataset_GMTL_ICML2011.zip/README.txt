This is the data set used in "Learning with Whom to Share in Multi-task Feature Learning" presented in ICML 2011.

URL: http://www.icml-2011.org/papers/344_icmlpaper.pdf

(1). USPS
# of classes: 10
# of dimensions: 64
# of training sample: 1000
# of validation sample: 500
# of testing sample: 500

(2). MNIST
# of classes: 10
# of dimensions: 87
# of training sample: 1000
# of validation sample: 500
# of testing sample: 500

(3). Animal
# of classes: 20
# of dimensions: 202
# of training sample: 1000
# of validation sample: 400
# of testing sample: 600